create function delete_ingr() returns trigger
    language plpgsql
as
$$
BEGIN
  delete from ingred where recipe in (select recipe from ingred rec
  left join (select tt.array_to_string from (select distinct array_to_string(regexp_matches(ingredients, '[a-zA-Z]{3,}', 'g'),'') from recipes)tt ) tt  on (tt.array_to_string = recipe)
  where array_to_string is null);
  RETURN NEW;
END;
$$;

alter function delete_ingr() owner to postgres;

