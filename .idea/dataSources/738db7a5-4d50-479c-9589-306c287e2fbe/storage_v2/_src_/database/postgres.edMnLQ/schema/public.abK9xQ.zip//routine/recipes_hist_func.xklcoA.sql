create function recipes_hist_func() returns trigger
    language plpgsql
as
$$
BEGIN
  IF( select count(1) from recipes where OLD.title != NEW.title or  OLD.img != NEW.img or  OLD.ingredients != NEW.ingredients or  OLD.recipe != NEW.recipe ) <> (select 0) then
    insert into recipes_hist values(default,OLD.title, OLD.img,OLD.ingredients,OLD.recipe,OLD.category,OLD.id);
    RETURN NEW;
  ELSE
      RETURN OLD;
    END IF;
END;
$$;

alter function recipes_hist_func() owner to postgres;

