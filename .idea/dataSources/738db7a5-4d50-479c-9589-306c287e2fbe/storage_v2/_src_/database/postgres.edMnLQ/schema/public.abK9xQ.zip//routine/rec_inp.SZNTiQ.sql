create function rec_inp(n integer) returns void
    language plpgsql
as
$$
BEGIN

FOR i IN 1 .. n
LOOP
   perform rec();
END LOOP;

END;
$$;

alter function rec_inp(integer) owner to postgres;

