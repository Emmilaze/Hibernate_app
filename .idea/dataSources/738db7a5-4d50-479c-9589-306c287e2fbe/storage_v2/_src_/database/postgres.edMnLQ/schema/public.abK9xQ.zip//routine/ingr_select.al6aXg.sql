create function ingr_select() returns trigger
    language plpgsql
as
$$
BEGIN                                                                                                                                                                                                                                
   IF (select count(1) 
     from (select regexp_split_to_table(ingredients, ',')  from recipes) res) > (select count(1) from ingred ) then
    with to_ins as(
    select distinct regexp_replace(regexp_split_to_table(ingredients, ','),'^\s','') r from recipes)
      insert into ingred
     select nextval('ingr'), r from to_ins 
    where r not in (select array_to_string(regexp_matches(r,'.*[\d].*', 'g'),'') a) and 
    r not in (select recipe from ingred);
      RETURN NEW;                                                                                                                                                                                                                         
    ELSE RETURN OLD;                                                                                                                                                                                                                     
    END IF;                                                                                                                                                                                                                              
    END;
$$;

alter function ingr_select() owner to postgres;

