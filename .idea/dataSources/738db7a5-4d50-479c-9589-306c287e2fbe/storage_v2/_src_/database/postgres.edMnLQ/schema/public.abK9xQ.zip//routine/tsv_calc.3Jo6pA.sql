create function tsv_calc() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.id not in (select recipe from search_ingr)then
       insert into search_ingr values(default,NEW.id,to_tsvector(NEW.ingredients));
       RETURN NEW;
    ELSE
    update search_ingr set search =  to_tsvector(NEW.ingredients) where recipe = NEW.id;
    RETURN NEW;
    END IF;
END;
$$;

alter function tsv_calc() owner to postgres;

