create function votes_update_for_recipe() returns trigger
    language plpgsql
as
$$
BEGIN
IF (select count(1) from voted where recipe_id = NEW.recipe_id) <> (select votes from recipes where id = NEW.recipe_id) then
update recipes set votes = (select count(*) from voted where recipe_id = NEW.recipe_id) where id = NEW.recipe_id;
    RETURN NEW;
    ELSE
    update recipes set votes = (select count(*) from voted where recipe_id = OLD.recipe_id) where id = OLD.recipe_id;
    RETURN NEW;
    END IF;
END;
$$;

alter function votes_update_for_recipe() owner to postgres;

