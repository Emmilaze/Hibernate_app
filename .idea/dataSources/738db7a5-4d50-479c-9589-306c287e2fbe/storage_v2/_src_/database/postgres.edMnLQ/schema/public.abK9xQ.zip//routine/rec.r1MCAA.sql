create function rec() returns void
    language plpgsql
as
$$
BEGIN
insert into recipes select (select coalesce( (select max(id)from recipes)+1,1)) id,
 (select concat(concat((ARRAY['first','second','third'])[floor(random() * 3+1)],(ARRAY['dish','soup','desert','icecream'])[floor(random() * 4+1)])) ) title,
 (select 'text') img,
 (select concat(concat((ARRAY['first ','second ','third '])[floor(random() * 3+1)],(ARRAY['qasfdasd ','wssssss ','e1 ','r1 '])[floor(random() * 4+1)]),(concat((ARRAY['m2 ','r2 ','d2 '])[floor(random() * 3+1)],(ARRAY['q2 ','w2 ','e2 ','r2 '])[floor(random() * 4)]) ))) ingredients,
 (select 'long recipe') recipe,
 (select now())publication_date ,
 (SELECT id FROM users ORDER BY RANDOM() LIMIT 1)author_id,
 (select 0) viewed;
END;
$$;

alter function rec() owner to postgres;

